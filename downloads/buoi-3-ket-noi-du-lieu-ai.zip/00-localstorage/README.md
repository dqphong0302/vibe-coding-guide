# Ví dụ 0 — LocalStorage trong trình duyệt

## Bài toán

Lưu checklist chuẩn bị trạm mô phỏng với đúng hai trường: `station` và `readiness`. Đây là dữ liệu giả lập, không có thông tin người bệnh hoặc định danh học viên.

## Cách chạy

1. Mở folder này bằng VS Code.
2. Dùng Live Server để mở `index.html`, hoặc chạy một static server đơn giản.
3. Chọn trạm và mức sẵn sàng, rồi bấm **Lưu vào trình duyệt**.
4. Tải lại trang. Bản ghi phải vẫn xuất hiện.
5. Mở trang ở trình duyệt hoặc thiết bị khác. Dữ liệu không tự đồng bộ sang đó.

## Dữ liệu nằm ở đâu?

`localStorage` thuộc origin của website trong trình duyệt hiện tại. JavaScript lưu mảng JSON dưới khóa `ump_buoi3_station_checks_v1`.

## Ưu điểm

- Dễ nhất cho người mới, không cần backend hoặc tài khoản cloud.
- Dữ liệu còn sau khi tải lại trang.
- Phù hợp cho cài đặt cá nhân, bản nháp và prototype một thiết bị.

## Nhược điểm

- Không đồng bộ giữa trình duyệt hoặc thiết bị.
- Người dùng có thể xóa dữ liệu trình duyệt.
- JavaScript của cùng origin có thể đọc dữ liệu; không lưu secret hoặc dữ liệu nhạy cảm.
- Không thay thế database khi cần nhiều người dùng, phân quyền, backup hoặc truy vấn.

## Tiêu chí hoàn thành

- Thêm được một bản ghi giả lập.
- Tải lại trang vẫn thấy bản ghi.
- Xóa dữ liệu lab có hộp xác nhận.
- Không có dữ liệu người bệnh, họ tên, API key hoặc mật khẩu.

Xem `PROMPTS.md` để làm từng bước với AI.
