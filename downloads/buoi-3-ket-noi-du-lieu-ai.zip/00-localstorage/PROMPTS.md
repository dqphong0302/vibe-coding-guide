# Prompt AI — LocalStorage

## 1. Hiểu luồng dữ liệu

```text
Chỉ làm trong folder 00-localstorage. Hãy đọc README.md, index.html, styles.css và app.js.
Chưa sửa file. Giải thích cho người mới: dữ liệu đi từ form vào localStorage như thế nào,
STORAGE_KEY dùng để làm gì, và vì sao tải lại trang vẫn còn dữ liệu nhưng thiết bị khác không thấy.
```

## 2. Chạy và kiểm tra lần đầu

```text
Chỉ làm trong folder 00-localstorage. Hướng dẫn tôi mở app bằng Live Server.
Cho đúng 4 thao tác kiểm tra: thêm bản ghi, tải lại trang, xem DevTools > Application > Local Storage,
và xóa dữ liệu lab. Chưa sửa mã nếu chưa có lỗi.
```

## 3. Kiểm tra dữ liệu tối giản

```text
Review app.js ở chế độ chỉ đọc. Xác nhận ứng dụng chỉ lưu station, readiness, id và createdAt.
Không thêm họ tên, mã sinh viên, ghi chú tự do hoặc dữ liệu người bệnh.
Trả lời bằng bảng: trường, nguồn tạo, mục đích, có nhạy cảm không.
```

## 4. Xử lý dữ liệu lưu bị hỏng

```text
Chỉ làm trong folder 00-localstorage. Kiểm tra hàm readRecords xử lý JSON hỏng như thế nào.
Nếu cần sửa, chỉ sửa tối thiểu để app không crash, hiển thị thông báo dễ hiểu và không tự xóa dữ liệu
khi chưa có thao tác xác nhận của người dùng. Cho cách tạo lỗi thử trong DevTools và cách phục hồi.
```

## 5. Review trước khi nộp

```text
Review folder 00-localstorage, chưa sửa. Kiểm tra semantic HTML, label, focus, responsive 390px,
không dùng innerHTML cho dữ liệu lưu, có giới hạn tối đa 20 bản ghi, và không lưu secret/dữ liệu nhạy cảm.
Đưa checklist đạt/chưa đạt và tối đa 3 sửa đổi quan trọng nhất.
```
