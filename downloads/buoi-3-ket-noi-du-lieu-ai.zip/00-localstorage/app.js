const STORAGE_KEY = 'ump_buoi3_station_checks_v1';

const form = document.querySelector('#check-form');
const stationInput = document.querySelector('#station');
const readinessInput = document.querySelector('#readiness');
const list = document.querySelector('#record-list');
const emptyState = document.querySelector('#empty-state');
const status = document.querySelector('#status');
const clearButton = document.querySelector('#clear-button');

function readRecords() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return [];
  try {
    const value = JSON.parse(raw);
    return Array.isArray(value) ? value : [];
  } catch {
    status.textContent = 'Dữ liệu lưu bị hỏng. Hãy xóa dữ liệu lab rồi thử lại.';
    return [];
  }
}

function writeRecords(records) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function render() {
  const records = readRecords();
  list.replaceChildren();
  emptyState.hidden = records.length > 0;
  for (const record of records) {
    const item = document.createElement('li');
    item.className = 'record-card';

    const content = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = record.station;
    const time = document.createElement('span');
    time.textContent = new Date(record.createdAt).toLocaleString('vi-VN');
    content.append(title, time);

    const state = document.createElement('span');
    state.className = 'state';
    state.textContent = record.readiness;
    item.append(content, state);
    list.append(item);
  }
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const station = stationInput.value;
  const readiness = readinessInput.value;
  if (!station || !readiness) return;

  const records = readRecords();
  records.unshift({ id: crypto.randomUUID(), station, readiness, createdAt: new Date().toISOString() });
  writeRecords(records.slice(0, 20));
  form.reset();
  status.textContent = 'Đã lưu trong trình duyệt này. Hãy tải lại trang để kiểm tra.';
  render();
});

clearButton.addEventListener('click', () => {
  if (!localStorage.getItem(STORAGE_KEY)) return;
  if (!window.confirm('Xóa toàn bộ dữ liệu giả lập của ví dụ LocalStorage?')) return;
  localStorage.removeItem(STORAGE_KEY);
  status.textContent = 'Đã xóa dữ liệu lab.';
  render();
});

render();
