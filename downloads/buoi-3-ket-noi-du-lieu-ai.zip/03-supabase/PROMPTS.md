# Prompt AI — Supabase

## 1. Hiểu phần khó nhất

```text
Đọc README.md, schema.sql, config.js và app.js. Chưa sửa gì.
Giải thích bằng ngôn ngữ người mới: Anonymous Auth là gì, owner_id là gì, RLS bảo vệ dữ liệu thế nào.
Chỉ ra key nào được dùng trong frontend và key nào tuyệt đối không được dùng.
```

## 2. Hướng dẫn thiết lập

```text
Hướng dẫn tôi tạo Supabase project cho lab bằng dữ liệu giả lập.
Chia thành các checkpoint: tạo project, chạy schema.sql, bật Anonymous sign-ins,
lấy Project URL + anon/publishable key, cấu hình config.js, chạy bằng Live Server.
Không yêu cầu tôi gửi key cho bạn.
```

## 3. Kiểm tra schema trước khi chạy

```text
Review schema.sql theo ba tiêu chí: bảng chỉ có trường tối thiểu; RLS đã bật;
policy SELECT và INSERT ràng buộc auth.uid() = owner_id.
Chưa sửa. Nếu có lỗi, đưa đúng đoạn SQL nhỏ cần thay và giải thích cách kiểm tra trong Table Editor.
```

## 4. Kiểm thử hai phiên

```text
Viết kịch bản kiểm thử quyền bằng hai cửa sổ ẩn danh A và B.
A tạo một đề xuất, B tạo một đề xuất khác. Kết quả đúng là mỗi phiên chỉ thấy dữ liệu của mình.
Cho bảng: bước, thao tác, kết quả mong đợi, nếu sai thì kiểm tra gì.
```

## 5. Xử lý lỗi RLS

```text
Supabase trả lỗi quyền khi INSERT. Không tắt RLS và không dùng service_role key.
Hãy cho tôi kiểm tra theo thứ tự: anonymous session, auth.uid(), owner_id default, policy INSERT.
Mỗi vòng chỉ sửa một nguyên nhân và nêu cách thử lại.
```
