# 03. Supabase

## Kết quả

Một danh sách **đề xuất cải tiến buổi mô phỏng lâm sàng** dùng Supabase Postgres và Anonymous Auth. Dữ liệu do cloud quản lý, còn giao diện chỉ dùng anon key + URL công khai. Không nhập tình huống bệnh án hay dữ liệu người bệnh.

## Bước làm

1. Tạo project mới tại Supabase; vào **SQL Editor** và chạy `schema.sql`.
2. Vào Authentication → Providers → bật **Anonymous sign-ins**.
3. Vào Project Settings → API, chép Project URL và anon/publishable key vào `config.js`.
4. Mở `index.html` qua Live Server, thêm ý tưởng và tải lại để kiểm tra.

## Tiêu chí hoàn thành

- `config.js` chỉ chứa Project URL và anon/publishable key.
- Tạo được một đề xuất ngắn, không có dữ liệu người bệnh.
- Tải lại trang vẫn thấy đề xuất của phiên hiện tại.
- Mở phiên ẩn danh khác không thấy dữ liệu của phiên trước.

Xem các prompt AI theo thứ tự trong `PROMPTS.md`.

## Ưu và nhược

Ưu: Postgres thật, Auth, Storage, dashboard, API tự sinh; hợp nhóm cần triển khai nhanh. Nhược: cần hiểu RLS và quota; phụ thuộc dịch vụ cloud; thiết kế quyền sai có thể lộ dữ liệu. Không được dùng service_role key trong frontend.
