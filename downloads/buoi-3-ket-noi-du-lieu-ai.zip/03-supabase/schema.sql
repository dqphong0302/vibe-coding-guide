create table public.ideas (id bigint generated always as identity primary key, owner_id uuid not null default auth.uid(), title text not null check (char_length(title) between 3 and 180), created_at timestamptz not null default now());
alter table public.ideas enable row level security;
create policy "Users see their ideas" on public.ideas for select using (auth.uid() = owner_id);
create policy "Users add their ideas" on public.ideas for insert with check (auth.uid() = owner_id);
