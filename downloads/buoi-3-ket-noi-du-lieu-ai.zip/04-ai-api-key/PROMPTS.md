# Prompt AI — Ứng dụng AI qua backend

## 1. Chạy không cần API key

```text
Đọc README.md, .env.example, server.js và public/app.js. Chưa sửa gì.
Hướng dẫn tôi chạy với MOCK_AI=true. Nêu vì sao chế độ này phù hợp cho lớp học,
cách nhận biết server đang ở MOCK_AI và cách chứng minh browser không chứa API key.
```

## 2. Giải thích ranh giới frontend/backend

```text
Giải thích cho người mới vì sao public/app.js chỉ gọi /api/draft còn server.js mới được đọc .env.
Liệt kê ba nơi không được đặt API key và hai việc cần làm nếu key bị lộ.
Không yêu cầu tôi gửi key hoặc nội dung .env.
```

## 3. Đổi nội dung checklist

```text
Hãy đổi bản checklist MOCK_AI trong server.js để phù hợp với trạm [tên trạm giả lập].
Giữ tối đa 5 bước, không thêm chỉ định/chẩn đoán/điều trị, không dùng dữ liệu người bệnh.
Chỉ sửa chuỗi kết quả mock và cho tôi xem diff.
```

## 4. Bật AI thật có kiểm soát

```text
Giảng viên đã cho phép dùng API. Hướng dẫn tôi bật AI thật bằng .env:
điền OPENAI_API_KEY trên máy, đặt MOCK_AI=false, chọn model và khởi động lại server.
Không yêu cầu tôi gửi key. Thêm checklist kiểm tra key không nằm trong frontend, Git hoặc ảnh chụp.
```

## 5. Review đầu ra AI

```text
Tạo rubric 4 tiêu chí để con người duyệt checklist do AI sinh:
đúng phạm vi đào tạo mô phỏng, không có dữ liệu người bệnh, không bịa quy định,
các bước rõ và có người chịu trách nhiệm phê duyệt.
Mỗi tiêu chí dùng mức Đạt / Cần sửa / Loại bỏ.
```
