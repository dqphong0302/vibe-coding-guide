# 04. Ứng dụng AI dùng API key an toàn

## Kết quả

Web app nhận tên một **trạm thực hành mô phỏng** và tạo bản nháp checklist chuẩn bị. Browser chỉ gọi backend `/api/draft`; backend mới gọi OpenAI API. Đây chỉ là hỗ trợ biên soạn; không dùng để quyết định lâm sàng.

## Chạy ứng dụng

1. Cài Node.js LTS và mở Terminal tại thư mục này.
2. Chạy `pnpm install`, sao chép `.env.example` thành `.env`. Giữ `MOCK_AI=true` để học không cần API key.
3. Chạy `pnpm dev`, mở `http://localhost:3001`.
4. Nhập tên trạm giả lập, tạo bản nháp, sau đó **con người kiểm tra và sửa** trước khi sử dụng.
5. Chỉ khi giảng viên cho phép dùng AI thật: điền key, đổi `MOCK_AI=false`, khởi động lại server.

## Tiêu chí hoàn thành

- Chạy được ở `MOCK_AI=true` mà không cần API key.
- Browser không chứa API key và chỉ gọi `/api/draft`.
- Nhập một tên trạm và nhận checklist mô phỏng.
- Học viên giải thích được vì sao kết quả phải được con người duyệt.

Xem các prompt AI theo thứ tự trong `PROMPTS.md`.

## Quy tắc an toàn

- Không đặt API key trong `index.html`, `app.js`, Git, ảnh chụp màn hình, hoặc prompt gửi cho AI.
- Không gửi dữ liệu bệnh nhân/định danh cá nhân. Dùng dữ liệu đã ẩn danh hoặc giả lập.
- Giới hạn đầu vào, giới hạn chi phí, ghi log tối thiểu, và luôn có bước con người duyệt kết quả.
