# Prompt AI — Google Sheets + Apps Script

Chạy từng prompt, không gửi đồng thời.

## 1. Hiểu luồng dữ liệu

```text
Đọc README.md, index.html, app.js, config.js và Code.gs trong folder hiện tại. Chưa sửa gì.
Giải thích luồng dữ liệu từ ba trường maNhom, tram, ca đến năm cột Google Sheets.
Chỉ ra đúng hai placeholder tôi phải tự điền. Kết thúc bằng checklist 5 bước chạy.
```

## 2. Kiểm tra trước khi deploy

```text
Kiểm tra index.html, app.js và Code.gs có dùng cùng ba tên trường maNhom, tram, ca hay không.
Không thay đổi giao diện. Nếu không khớp, sửa tối thiểu và cho tôi xem diff.
Sau đó nêu một dữ liệu thử không có thông tin cá nhân.
```

## 3. Hướng dẫn deploy cầm tay chỉ việc

```text
Tôi là người mới. Hãy hướng dẫn từng thao tác deploy Code.gs thành Apps Script Web app.
Mỗi bước chỉ 1–2 câu, nói rõ chỗ lấy SPREADSHEET_ID và URL /exec.
Không yêu cầu tôi gửi các giá trị đó cho bạn. Sau mỗi bước ghi dấu hiệu kiểm tra thành công.
```

## 4. Đổi bối cảnh nhưng giữ dữ liệu ít

```text
Hãy đổi ba lựa chọn trạm mô phỏng trong index.html thành [danh sách của nhóm].
Không thêm họ tên, số điện thoại, mã sinh viên, dữ liệu người bệnh hoặc trường văn bản tự do.
Chỉ sửa index.html và cho tôi biết cần deploy lại Apps Script hay không.
```

## 5. Xử lý lỗi

```text
Form gửi xong nhưng chưa thấy dòng mới trong Sheets. Hãy cho tôi quy trình kiểm tra theo thứ tự:
URL /exec, config.js, tên sheet YeuCau, SPREADSHEET_ID, Executions trong Apps Script.
Mỗi lần chỉ yêu cầu kiểm tra một mục; không đề xuất tắt bảo mật hoặc chia sẻ dữ liệu thật.
```
