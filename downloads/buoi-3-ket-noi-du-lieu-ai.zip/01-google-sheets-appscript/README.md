# 01. Google Sheets + Apps Script

## Kết quả

Một form HTML gửi **đăng ký ca thực hành mô phỏng** vào Google Sheets. Dữ liệu nhập chỉ gồm `Mã nhóm`, `Trạm mô phỏng`, `Ca học`; không có họ tên hoặc dữ liệu người bệnh.

## Bước làm

1. Tải `du_lieu_mau_upload_drive.xlsx` lên Google Drive, nhấp phải **Open with → Google Sheets**.
2. Đặt tên bảng tính là `Dang ky ca thuc hanh mo phong - Buoi 3`; đổi tên sheet thành `YeuCau`.
3. Trong Google Sheets: **Extensions → Apps Script**. Dán nội dung `Code.gs` vào dự án.
4. Thay `PASTE_SPREADSHEET_ID_HERE` bằng mã giữa `/d/` và `/edit` trong URL Google Sheets.
5. Bấm Deploy → New deployment → Web app. Chạy dưới tài khoản của bạn; quyền truy cập: Anyone (chỉ dùng cho lab dữ liệu giả lập). Cấp quyền và sao chép URL `/exec`.
6. Mở `config.js`, điền URL `/exec`. Mở `index.html` bằng Live Server hoặc một web server tĩnh.
7. Gửi form; quay lại Sheets kiểm tra dòng mới trong sheet `YeuCau`. Kiểm tra đủ năm cột và trạng thái mặc định `Mới`.

## Tiêu chí hoàn thành

- Mở URL `/exec` thấy thông báo Apps Script hoạt động.
- Gửi form một lần và Sheets xuất hiện đúng một dòng mới.
- Dòng mới chỉ có thời gian, mã nhóm, trạm, ca và trạng thái.
- Học viên có thể giải thích `config.js` và `SPREADSHEET_ID` dùng để làm gì.

Xem các prompt AI theo thứ tự trong `PROMPTS.md`.

## Điểm cần biết

Ưu: dựng nhanh, dễ cho nhóm cùng xem/sửa, phù hợp danh mục và quy trình nhẹ. Nhược: không thay thế CSDL quan hệ; kiểm soát quyền/hiệu năng/khoá ghi hạn chế. Không dùng URL web app public cho dữ liệu nhạy cảm.
