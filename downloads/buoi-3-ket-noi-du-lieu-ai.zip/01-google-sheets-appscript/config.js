window.APP_CONFIG = {
  appsScriptUrl: 'PASTE_YOUR_WEB_APP_EXEC_URL_HERE'
};
