const SPREADSHEET_ID = 'PASTE_SPREADSHEET_ID_HERE';
const SHEET_NAME = 'YeuCau';

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);
    if (!sheet) throw new Error(`Không tìm thấy sheet: ${SHEET_NAME}`);
    if (!payload.maNhom || !payload.tram || !payload.ca) {
      throw new Error('Vui lòng nhập mã nhóm, trạm mô phỏng và ca học.');
    }
    sheet.appendRow([new Date(), payload.maNhom, payload.tram, payload.ca, 'Mới']);
    return json({ ok: true, message: 'Đã ghi dữ liệu vào Google Sheets.' });
  } catch (error) {
    return json({ ok: false, message: error.message });
  }
}

function doGet() {
  return json({ ok: true, message: 'Apps Script đang hoạt động.' });
}

function json(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
