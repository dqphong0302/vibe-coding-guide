# Buổi 3 — Kết nối dữ liệu và AI an toàn

Mỗi thư mục là một ví dụ độc lập. Dùng **dữ liệu tối giản và giả lập**, không đưa dữ liệu người bệnh hoặc API key thật vào mã nguồn.

0. `00-localstorage`: checklist chuẩn bị trạm với 2 trường nhập, lưu ngay trong trình duyệt; không cần backend.
1. `01-google-sheets-appscript`: đăng ký ca mô phỏng với 3 trường nhập, lưu vào Google Sheets qua Apps Script; có Excel mẫu tải lên Drive.
2. `02-sqlite-backend`: nhật ký sẵn sàng của trạm mô phỏng với 2 trường nhập; SQLite chạy cùng backend Node.js tối giản.
3. `03-supabase`: đề xuất cải tiến ca mô phỏng với 1 trường nhập; Supabase Database + Auth ẩn danh, RLS là bắt buộc.
4. `04-ai-api-key`: trợ lý tạo checklist với 1 trường nhập; mặc định có chế độ mô phỏng, API key chỉ nằm ở backend khi bật AI thật.

Mỗi ví dụ có `README.md`, `PROMPTS.md`, mã nguồn và tiêu chí hoàn thành. Bắt đầu bằng `PROMPT_HUONG_DAN_CHO_HOC_VIEN.md`; học viên không cần làm cả năm ví dụ trong một buổi.
