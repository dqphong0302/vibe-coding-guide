# Cách dùng AI để làm năm ví dụ Buổi 3

## Nguyên tắc chung

1. Mở **một folder ví dụ**, không gửi cả năm folder cho AI cùng lúc.
2. Prompt đầu tiên chỉ yêu cầu AI đọc và giải thích; chưa sửa mã.
3. Mỗi prompt chỉ yêu cầu **một thay đổi nhỏ**.
4. Luôn yêu cầu AI nêu file sẽ sửa, cách kiểm tra và cách quay lại khi lỗi.
5. Không dán API key, mật khẩu, dữ liệu người bệnh hoặc nội dung bệnh án vào chat.
6. Sau mỗi bước: chạy thử → chụp lỗi chính xác → gửi lỗi cho AI → yêu cầu sửa tối thiểu.

## Công thức prompt năm phần

```text
Vai trò: Bạn là trợ giảng lập trình cho người mới.
Mục tiêu: [một kết quả cụ thể].
Bối cảnh: Tôi đang mở folder [tên folder], dùng dữ liệu mô phỏng.
Giới hạn: Không thêm framework, không đổi cấu trúc folder, không yêu cầu bí mật.
Đầu ra: Nêu file cần sửa, đưa bản sửa tối thiểu, lệnh chạy và 3 bước kiểm tra.
```

## Prompt khởi đầu dùng cho mọi folder

```text
Bạn là trợ giảng lập trình cho người mới. Hãy đọc README.md và các file trong folder hiện tại.
Chưa sửa gì. Hãy trả lời ngắn gọn:
1) Ứng dụng làm gì?
2) Dữ liệu đi từ đâu đến đâu?
3) Tôi phải cấu hình đúng những placeholder nào?
4) Lệnh chạy là gì?
5) Ba dấu hiệu nào chứng minh ứng dụng chạy đúng?
Không yêu cầu tôi gửi API key, mật khẩu hoặc dữ liệu người bệnh.
```

## Prompt khi gặp lỗi

```text
Tôi đang làm bước [số bước] trong README.md. Lệnh hoặc thao tác vừa chạy là: [ghi lại].
Lỗi nguyên văn: [dán 10–30 dòng liên quan, xóa key/URL nhạy cảm].
Hãy xác định một nguyên nhân có khả năng nhất, chỉ đề xuất một thay đổi nhỏ để thử,
nêu chính xác file/dòng cần sửa và cách kiểm tra sau khi sửa. Không viết lại toàn bộ dự án.
```

## Prompt kiểm tra trước khi nộp

```text
Hãy kiểm tra folder hiện tại theo vai trò reviewer. Chỉ đọc, chưa sửa.
Đối chiếu README.md và báo theo bảng: yêu cầu, bằng chứng trong file, cách chạy kiểm tra, đạt/chưa đạt.
Kiểm tra thêm: dữ liệu có tối giản và giả lập không; có key trong frontend/Git không;
có bước con người duyệt đầu ra AI không. Sau đó đề xuất tối đa 3 sửa đổi quan trọng nhất.
```

Mỗi folder có `PROMPTS.md` với prompt riêng cho ví dụ đó.
