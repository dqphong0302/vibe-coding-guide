# Prompt AI — SQLite + backend

## 1. Hiểu kiến trúc

```text
Đọc README.md, server.js và public/app.js. Chưa sửa gì.
Vẽ luồng bằng một dòng: form → endpoint → bảng SQLite → giao diện.
Giải thích vì sao browser không đọc trực tiếp data/noi-bo.db.
Nêu lệnh chạy và 4 dấu hiệu kiểm tra thành công.
```

## 2. Kiểm tra môi trường

```text
Hãy hướng dẫn tôi kiểm tra phiên bản Node.js trước khi cài.
Dự án yêu cầu Node >=22.13 và dùng node:sqlite, pnpm, Express.
Cho đúng các lệnh kiểm tra, giải thích kết quả mong đợi và dừng nếu phiên bản chưa đạt.
Không cài thêm thư viện SQLite khác.
```

## 3. Thay lựa chọn trạm

```text
Trong public/index.html, thay danh sách trạm bằng [ba trạm của nhóm].
Giữ đúng hai trường station và result; không thêm người phụ trách hay dữ liệu người bệnh.
Không sửa server.js nếu không cần. Cho tôi xem diff và cách kiểm tra.
```

## 4. Đọc lỗi API

```text
Khi bấm Ghi kiểm tra, browser báo lỗi. Hãy hướng dẫn tôi mở DevTools → Network,
xem request POST /api/checks, status code và response JSON.
Chỉ sau khi tôi gửi status code và message đã xóa dữ liệu nhạy cảm, mới đề xuất một sửa đổi tối thiểu.
```

## 5. Kiểm tra tính lưu trữ

```text
Hãy cho tôi kịch bản kiểm thử 5 bước chứng minh SQLite lưu dữ liệu:
tạo một dòng giả lập, tải lại trang, dừng server, chạy lại server, kiểm tra file .db.
Không xóa database và không dùng dữ liệu thật.
```
