# 02. SQLite + backend Node.js

## Kết quả

Ứng dụng **nhật ký sẵn sàng của trạm mô phỏng**. Dữ liệu nhập chỉ gồm `Trạm` và `Kết quả`; trình duyệt gọi API `/api/checks`, backend mới được quyền đọc/ghi SQLite.

## Chạy ứng dụng

1. Cài Node.js 22.13 trở lên, mở Terminal tại thư mục này.
2. Chạy `pnpm install` rồi `pnpm dev`.
3. Mở `http://localhost:3000`. Ghi một lần kiểm tra; tải lại trang để thấy dữ liệu còn tồn tại.

## Tiêu chí hoàn thành

- Terminal hiển thị `http://localhost:3000`.
- Ghi được một dòng gồm trạm và kết quả.
- Tải lại trang vẫn thấy dòng vừa tạo.
- Học viên chỉ ra được file `data/noi-bo.db` và giải thích vì sao browser không mở file này trực tiếp.

Xem các prompt AI theo thứ tự trong `PROMPTS.md`.

## Ưu và nhược

Ưu: một file, cài đặt nhẹ, truy vấn quan hệ tốt, dữ liệu không công khai trên trình duyệt. Nhược: cần backend/host riêng; không phù hợp nhiều máy chủ ghi đồng thời; phải sao lưu file `.db`.

Không commit `data/*.db` thật lên Git. Khi triển khai, dùng HTTPS, xác thực người dùng, phân quyền và sao lưu định kỳ.
