/**
 * ui-render.js - DataTable rendering, Search & Filter handlers, and Stat counters
 */

function renderInitiativesTable() {
  const tableBody = document.getElementById('initiatives-table-body');
  const emptyState = document.getElementById('empty-state');
  const badgeCount = document.getElementById('badge-list-count');
  const searchVal = (document.getElementById('filter-search')?.value || '').toLowerCase().trim();
  const statusVal = document.getElementById('filter-status')?.value || 'ALL';
  const deptVal = document.getElementById('filter-dept')?.value || 'ALL';

  const allItems = getInitiatives();

  const filtered = allItems.filter(item => {
    const matchSearch = !searchVal || 
      item.title.toLowerCase().includes(searchVal) || 
      item.author.toLowerCase().includes(searchVal) || 
      item.id.toLowerCase().includes(searchVal);
    const matchStatus = statusVal === 'ALL' || item.status === statusVal;
    const matchDept = deptVal === 'ALL' || item.department.includes(deptVal);
    return matchSearch && matchStatus && matchDept;
  });

  if (badgeCount) {
    badgeCount.textContent = `${filtered.length} hồ sơ`;
  }

  if (!tableBody) return;

  tableBody.innerHTML = '';

  if (filtered.length === 0) {
    if (emptyState) emptyState.classList.remove('hidden');
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');

  filtered.forEach(item => {
    const tr = document.createElement('tr');
    tr.className = 'hover:bg-slate-50/80 transition group';

    // Status Badge colors
    let badgeClass = 'bg-blue-100 text-blue-800 border-blue-200';
    if (item.status === 'Đang thẩm định') badgeClass = 'bg-orange-100 text-orange-800 border-orange-200';
    if (item.status === 'Đạt giải') badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-200';
    if (item.status === 'Cần bổ sung') badgeClass = 'bg-amber-100 text-amber-800 border-amber-200';
    if (item.status === 'Không đạt') badgeClass = 'bg-red-100 text-red-800 border-red-200';

    tr.innerHTML = `
      <td class="py-3.5 px-4 font-bold text-[#083B76] whitespace-nowrap">
        ${item.id}
      </td>
      <td class="py-3.5 px-4 max-w-xs">
        <div class="font-bold text-slate-800 line-clamp-1 group-hover:text-[#083B76] transition">${item.title}</div>
        <div class="text-[11px] text-slate-400 mt-0.5">${item.field}</div>
      </td>
      <td class="py-3.5 px-4 whitespace-nowrap">
        <div class="font-medium text-slate-700">${item.author}</div>
        <div class="text-[11px] text-slate-400">${item.department}</div>
      </td>
      <td class="py-3.5 px-4 whitespace-nowrap">
        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold border ${badgeClass}">
          ${item.status}
        </span>
        ${item.scores && item.scores.total > 0 ? `<span class="ml-1 text-[11px] font-bold text-slate-500">(${item.scores.total}đ)</span>` : ''}
      </td>
      <td class="py-3.5 px-4 text-center whitespace-nowrap space-x-1">
        <button onclick="openCouncilScoringModal('${item.id}')" class="px-3 py-1.5 rounded-lg bg-teal-50 text-[#08A6A6] hover:bg-teal-100 font-bold text-xs transition border border-teal-200">
          ⚖️ Chấm điểm
        </button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

function updateDashboardStats() {
  const all = getInitiatives();
  const total = all.length;
  const submitted = all.filter(x => x.status === 'Đã nộp').length;
  const evaluating = all.filter(x => x.status === 'Đang thẩm định').length;
  const approved = all.filter(x => x.status === 'Đạt giải').length;

  const elTotal = document.getElementById('stat-total');
  const elSubmitted = document.getElementById('stat-submitted');
  const elEvaluating = document.getElementById('stat-evaluating');
  const elApproved = document.getElementById('stat-approved');

  if (elTotal) elTotal.textContent = total;
  if (elSubmitted) elSubmitted.textContent = submitted;
  if (elEvaluating) elEvaluating.textContent = evaluating;
  if (elApproved) elApproved.textContent = approved;
}

function initFilterHandlers() {
  const search = document.getElementById('filter-search');
  const status = document.getElementById('filter-status');
  const dept = document.getElementById('filter-dept');
  const btnReset = document.getElementById('btn-reset-demo');

  if (search) search.addEventListener('input', renderInitiativesTable);
  if (status) status.addEventListener('change', renderInitiativesTable);
  if (dept) dept.addEventListener('change', renderInitiativesTable);

  if (btnReset) {
    btnReset.addEventListener('click', () => {
      resetToSampleData();
      renderInitiativesTable();
      updateDashboardStats();
      showToast('Đã khôi phục 5 đề tài sáng kiến mẫu của UMP!', 'success');
    });
  }
}
