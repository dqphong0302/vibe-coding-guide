/**
 * app.js - Main Application Orchestrator
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 Initializing SKKN Innovation Portal for UMP...');

  // 1. Initialize Form Handlers
  initFormHandler();

  // 2. Initialize Filter & Search Listeners
  initFilterHandlers();

  // 3. Initialize Council Scoring Modal & Sliders
  initCouncilScoring();

  // 4. Initial Render of Data & Stats
  renderInitiativesTable();
  updateDashboardStats();

  // 5. Role Switcher Mockup
  const btnAuthor = document.getElementById('btn-view-author');
  const btnCouncil = document.getElementById('btn-view-council');

  if (btnAuthor && btnCouncil) {
    btnAuthor.addEventListener('click', () => {
      btnAuthor.className = 'px-3 py-1.5 rounded-md font-semibold bg-[#08A6A6] text-white transition-all';
      btnCouncil.className = 'px-3 py-1.5 rounded-md font-semibold text-slate-200 hover:text-white transition-all';
      showToast('Đang ở chế độ xem: Tác giả sáng kiến', 'success');
    });

    btnCouncil.addEventListener('click', () => {
      btnCouncil.className = 'px-3 py-1.5 rounded-md font-semibold bg-[#08A6A6] text-white transition-all';
      btnAuthor.className = 'px-3 py-1.5 rounded-md font-semibold text-slate-200 hover:text-white transition-all';
      showToast('Đang ở chế độ xem: Thư ký & Hội đồng đánh giá', 'success');
    });
  }

  console.log('✅ SKKN Innovation Portal ready!');
});
