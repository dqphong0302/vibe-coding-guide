/**
 * council.js - Council Evaluation Modal, Real-time Scoring & Decision Handlers
 */

let activeScoringProposal = null;

function initCouncilScoring() {
  const modal = document.getElementById('modal-scoring');
  const btnClose = document.getElementById('btn-close-modal');
  const btnTriggerAi = document.getElementById('btn-trigger-ai');

  const slider1 = document.getElementById('slider-crit-1');
  const slider2 = document.getElementById('slider-crit-2');
  const slider3 = document.getElementById('slider-crit-3');

  const btnApprove = document.getElementById('btn-approve');
  const btnRequestChanges = document.getElementById('btn-request-changes');
  const btnReject = document.getElementById('btn-reject');

  // Close modal
  if (btnClose && modal) {
    btnClose.addEventListener('click', () => modal.classList.add('hidden'));
  }

  // Realtime Slider Updates
  function handleSliderUpdate() {
    const s1 = parseInt(slider1.value, 10) || 0;
    const s2 = parseInt(slider2.value, 10) || 0;
    const s3 = parseInt(slider3.value, 10) || 0;

    const val1 = document.getElementById('val-crit-1');
    const val2 = document.getElementById('val-crit-2');
    const val3 = document.getElementById('val-crit-3');
    const totalEl = document.getElementById('val-total-score');

    if (val1) val1.textContent = s1;
    if (val2) val2.textContent = s2;
    if (val3) val3.textContent = s3;

    const total = s1 + s2 + s3;
    if (totalEl) {
      totalEl.textContent = total;
      if (total >= 70) {
        totalEl.className = 'text-3xl font-black text-emerald-600';
      } else {
        totalEl.className = 'text-3xl font-black text-orange-500';
      }
    }
  }

  if (slider1) slider1.addEventListener('input', handleSliderUpdate);
  if (slider2) slider2.addEventListener('input', handleSliderUpdate);
  if (slider3) slider3.addEventListener('input', handleSliderUpdate);

  // AI Assistant Button
  if (btnTriggerAi) {
    btnTriggerAi.addEventListener('click', () => {
      if (!activeScoringProposal) return;
      const aiBox = document.getElementById('ai-review-box');
      const aiText = document.getElementById('ai-summary-text');
      
      btnTriggerAi.innerHTML = '<span>⏳ Đang phân tích...</span>';
      
      setTimeout(() => {
        if (aiText) aiText.innerHTML = generateAiReview(activeScoringProposal);
        if (aiBox) aiBox.classList.remove('hidden');
        btnTriggerAi.innerHTML = '<span>✨ Đã phân tích xong</span>';
      }, 800);
    });
  }

  // Decisions
  if (btnApprove) {
    btnApprove.addEventListener('click', () => submitDecision('Đạt giải'));
  }
  if (btnRequestChanges) {
    btnRequestChanges.addEventListener('click', () => submitDecision('Cần bổ sung'));
  }
  if (btnReject) {
    btnReject.addEventListener('click', () => submitDecision('Không đạt'));
  }
}

function openCouncilScoringModal(id) {
  const all = getInitiatives();
  const found = all.find(item => item.id === id);
  if (!found) return;

  activeScoringProposal = found;

  const modal = document.getElementById('modal-scoring');
  const title = document.getElementById('modal-initiative-title');
  const code = document.getElementById('modal-initiative-code');
  const author = document.getElementById('modal-initiative-author');
  const summary = document.getElementById('modal-initiative-summary');
  const feedback = document.getElementById('modal-feedback');
  const aiBox = document.getElementById('ai-review-box');
  const btnTriggerAi = document.getElementById('btn-trigger-ai');

  if (title) title.textContent = found.title;
  if (code) code.textContent = found.id;
  if (author) author.textContent = `Tác giả: ${found.author} (${found.department})`;
  if (summary) summary.textContent = found.summary;
  if (feedback) feedback.value = found.feedback || '';
  if (aiBox) aiBox.classList.add('hidden');
  if (btnTriggerAi) btnTriggerAi.innerHTML = '<span>✨ AI Rà soát & Tóm tắt</span>';

  // Load existing scores or default
  const s1 = found.scores?.novelty || 25;
  const s2 = found.scores?.feasibility || 30;
  const s3 = found.scores?.impact || 30;

  const slider1 = document.getElementById('slider-crit-1');
  const slider2 = document.getElementById('slider-crit-2');
  const slider3 = document.getElementById('slider-crit-3');

  if (slider1) slider1.value = s1;
  if (slider2) slider2.value = s2;
  if (slider3) slider3.value = s3;

  document.getElementById('val-crit-1').textContent = s1;
  document.getElementById('val-crit-2').textContent = s2;
  document.getElementById('val-crit-3').textContent = s3;
  document.getElementById('val-total-score').textContent = s1 + s2 + s3;

  if (modal) modal.classList.remove('hidden');
}

function submitDecision(newStatus) {
  if (!activeScoringProposal) return;

  const s1 = parseInt(document.getElementById('slider-crit-1')?.value, 10) || 0;
  const s2 = parseInt(document.getElementById('slider-crit-2')?.value, 10) || 0;
  const s3 = parseInt(document.getElementById('slider-crit-3')?.value, 10) || 0;
  const total = s1 + s2 + s3;
  const feedbackText = document.getElementById('modal-feedback')?.value.trim() || 'Hội đồng đã hoàn tất đánh giá.';

  activeScoringProposal.status = newStatus;
  activeScoringProposal.scores = { novelty: s1, feasibility: s2, impact: s3, total };
  activeScoringProposal.feedback = feedbackText;

  updateInitiative(activeScoringProposal);
  renderInitiativesTable();
  updateDashboardStats();

  const modal = document.getElementById('modal-scoring');
  if (modal) modal.classList.add('hidden');

  showToast(`Đã chuyển trạng thái sáng kiến ${activeScoringProposal.id} sang [${newStatus}] với ${total}/100 điểm!`, 'success');
}
