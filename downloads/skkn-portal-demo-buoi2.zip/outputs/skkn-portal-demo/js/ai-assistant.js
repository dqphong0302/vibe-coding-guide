/**
 * ai-assistant.js - AI Assistant Review & Summarization Simulation
 */

function generateAiReview(proposal) {
  const noveltyKeywords = ['AI', 'tự động', 'số hóa', 'QR', 'chatbot', 'cảnh báo', 'điện tử'];
  const hasTech = noveltyKeywords.some(kw => proposal.title.toLowerCase().includes(kw.toLowerCase()));

  const points = [
    `📌 <b>Vấn đề cốt lõi:</b> Đề tài giải quyết bài toán quản lý thủ công và rủi ro sai sót thông tin tại ${proposal.department}.`,
    `💡 <b>Điểm mới & Sáng tạo:</b> ${hasTech ? 'Áp dụng công nghệ số hóa / AI giúp tự động hóa quy trình nghiệp vụ.' : 'Chuẩn hóa quy trình thực hiện giúp tinh gọn thời gian xử lý.'}`,
    `📈 <b>Hiệu quả dự kiến:</b> Nâng cao chất lượng phục vụ, giảm thiểu 30-50% thời gian thao tác thủ công cho cán bộ và sinh viên.`
  ];

  const suggestedField = proposal.field || 'Đổi mới Phương pháp Đào tạo & Giảng dạy';
  const completenessScore = proposal.fileName ? '95% (Đầy đủ minh chứng & biểu mẫu)' : '70% (Cần bổ sung tệp thuyết minh chi tiết)';

  return `
    <div class="space-y-2">
      <div class="text-slate-800 font-semibold">Tóm tắt 3 ý chính của Hội đồng AI:</div>
      <ul class="space-y-1 text-slate-600">
        ${points.map(p => `<li>${p}</li>`).join('')}
      </ul>
      <div class="pt-1.5 flex items-center justify-between text-[11px] text-slate-500 border-t border-teal-100">
        <span>Lĩnh vực phù hợp: <b class="text-[#083B76]">${suggestedField}</b></span>
        <span>Hồ sơ hợp lệ: <b class="text-emerald-600">${completenessScore}</b></span>
      </div>
    </div>
  `;
}
