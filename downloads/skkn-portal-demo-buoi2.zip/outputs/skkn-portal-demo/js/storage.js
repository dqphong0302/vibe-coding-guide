/**
 * storage.js - LocalStorage Management & Mock Data for SKKN Portal
 */

const STORAGE_KEY = 'UMP_SKKN_PROPOSALS_2026';

const INITIAL_SAMPLE_PROPOSALS = [
  {
    id: 'SKKN-2026-001',
    title: 'Ứng dụng AI cảnh báo tương tác thuốc tại Khoa Dược lâm sàng',
    author: 'ThS. DS. Lê Thị Mai',
    email: 'mai_le@ump.edu.vn',
    department: 'Khoa Dược',
    field: 'Cải tiến Khám chữa bệnh & Chăm sóc Bệnh nhân',
    summary: 'Xây dựng module AI tích hợp vào đơn thuốc điện tử giúp tự động đối soát và cảnh báo tương tác thuốc bất lợi theo thời gian thực.',
    fileName: 'thuyet-minh-ai-khoa-duoc.pdf',
    submittedAt: '2026-08-10',
    status: 'Đạt giải',
    scores: { novelty: 28, feasibility: 32, impact: 32, total: 92 },
    feedback: 'Đề tài có tính ứng dụng thực tế rất cao, khuyến khích nhân rộng ra toàn bệnh viện.'
  },
  {
    id: 'SKKN-2026-002',
    title: 'Số hóa quy trình đăng ký & điểm danh thực tập lâm sàng bằng QR động',
    author: 'BS. CKII. Trần Quốc Bảo',
    email: 'bao_tran@ump.edu.vn',
    department: 'Khoa Y',
    field: 'Đổi mới Phương pháp Đào tạo & Giảng dạy',
    summary: 'Giải pháp điểm danh sinh viên y khoa tại các khoa phòng bệnh viện qua QR động chống gian lận vị trí và xuất báo cáo tự động cho Bộ môn.',
    fileName: 'skkn-diem-danh-qr-khoa-y.pdf',
    submittedAt: '2026-08-12',
    status: 'Đang thẩm định',
    scores: { novelty: 24, feasibility: 30, impact: 28, total: 82 },
    feedback: 'Đang phân công phản biện 2.'
  },
  {
    id: 'SKKN-2026-003',
    title: 'Hệ thống quản lý vật tư tiêu hao phòng thực hành Nha khoa',
    author: 'TS. BS. Nguyễn Hoàng Nam',
    email: 'nam_nguyen@ump.edu.vn',
    department: 'Khoa Răng Hàm Mặt',
    field: 'Chuyển đổi số & Quản lý Hành chính',
    summary: 'Web app theo dõi định mức và tồn kho vật tư thực hành tiền lâm sàng, giảm 40% thất thoát và tối ưu đặt hàng định kỳ.',
    fileName: 'skkn-quan-ly-vat-tu-rhm.pdf',
    submittedAt: '2026-08-15',
    status: 'Đã nộp',
    scores: { novelty: 22, feasibility: 28, impact: 26, total: 76 },
    feedback: 'Chờ phân công giám khảo.'
  },
  {
    id: 'SKKN-2026-004',
    title: 'Quy trình tư vấn dinh dưỡng bệnh nhân ngoại trú ứng dụng chatbot Zalo',
    author: 'ThS. Nguyễn Thị Thu Hà',
    email: 'ha_thu@ump.edu.vn',
    department: 'Khoa Y tế Công cộng',
    field: 'Cải tiến Khám chữa bệnh & Chăm sóc Bệnh nhân',
    summary: 'Trợ lý ảo tự động nhắc lịch tái khám và hướng dẫn thực đơn mẫu cho bệnh nhân đái tháo đường qua Zalo OA.',
    fileName: 'skkn-dinh-duong-chatbot.pdf',
    submittedAt: '2026-08-17',
    status: 'Cần bổ sung',
    scores: { novelty: 20, feasibility: 22, impact: 20, total: 62 },
    feedback: 'Cần bổ sung số liệu đánh giá thử nghiệm trên 50 bệnh nhân trước khi xét vòng tiếp theo.'
  },
  {
    id: 'SKKN-2026-005',
    title: 'Bàn giao ca trực điện tử tại Bệnh viện Đại học Y Dược',
    author: 'BS. Phạm Minh Tuấn',
    email: 'tuan_pham@ump.edu.vn',
    department: 'Bệnh viện Đại học Y Dược TP.HCM',
    field: 'Chuyển đổi số & Quản lý Hành chính',
    summary: 'Chuẩn hóa biên bản giao ban ca trực qua form điện tử có chữ ký số, giúp truyền đạt thông tin người bệnh nặng không bị đứt gãy.',
    fileName: 'skkn-giao-ban-dien-tu.pdf',
    submittedAt: '2026-08-18',
    status: 'Đạt giải',
    scores: { novelty: 26, feasibility: 34, impact: 33, total: 93 },
    feedback: 'Giải pháp thiết thực, giảm thiểu sai sót y khoa khi chuyển ca.'
  }
];

function getInitiatives() {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    saveAllInitiatives(INITIAL_SAMPLE_PROPOSALS);
    return INITIAL_SAMPLE_PROPOSALS;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Error parsing initiatives data', e);
    return INITIAL_SAMPLE_PROPOSALS;
  }
}

function saveAllInitiatives(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function saveInitiative(newDoc) {
  const list = getInitiatives();
  list.unshift(newDoc);
  saveAllInitiatives(list);
  return list;
}

function updateInitiative(updatedDoc) {
  const list = getInitiatives();
  const index = list.findIndex(item => item.id === updatedDoc.id);
  if (index !== -1) {
    list[index] = { ...list[index], ...updatedDoc };
    saveAllInitiatives(list);
  }
  return list;
}

function resetToSampleData() {
  saveAllInitiatives(INITIAL_SAMPLE_PROPOSALS);
  return INITIAL_SAMPLE_PROPOSALS;
}
