/**
 * form-handler.js - Multi-step form management, validation & submission
 */

let currentStep = 1;
let uploadedFileName = 'thuyet-minh-skkn.pdf';

function initFormHandler() {
  const form = document.getElementById('form-skkn');
  const btnNext = document.getElementById('btn-next-step');
  const btnPrev = document.getElementById('btn-prev-step');
  const btnSubmit = document.getElementById('btn-submit');
  const dropZone = document.getElementById('drop-zone');
  const inputFile = document.getElementById('input-file');
  const fileNameDisplay = document.getElementById('file-name-display');
  const fileNameText = document.getElementById('file-name-text');

  // File upload trigger
  if (dropZone && inputFile) {
    dropZone.addEventListener('click', () => inputFile.click());
    inputFile.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        uploadedFileName = e.target.files[0].name;
        fileNameText.textContent = uploadedFileName;
        fileNameDisplay.classList.remove('hidden');
      }
    });
  }

  // Next Step
  if (btnNext) {
    btnNext.addEventListener('click', () => {
      if (validateCurrentStep(currentStep)) {
        currentStep++;
        updateStepUI(currentStep);
      }
    });
  }

  // Prev Step
  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      if (currentStep > 1) {
        currentStep--;
        updateStepUI(currentStep);
      }
    });
  }

  // Form Submit
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const author = document.getElementById('input-author').value.trim();
      const email = document.getElementById('input-email').value.trim();
      const department = document.getElementById('input-department').value;
      const title = document.getElementById('input-title').value.trim();
      const fieldRadio = document.querySelector('input[name="field"]:checked');
      const field = fieldRadio ? fieldRadio.value : 'Đổi mới Phương pháp Đào tạo & Giảng dạy';
      const summary = document.getElementById('input-summary').value.trim();
      const agreed = document.getElementById('input-agree').checked;

      if (!agreed) {
        showToast('Vui lòng đánh dấu cam kết bản quyền trước khi gửi.', 'error');
        return;
      }

      // Generate ID
      const list = getInitiatives();
      const nextNum = list.length + 1;
      const id = `SKKN-2026-${String(nextNum).padStart(3, '0')}`;

      const newProposal = {
        id,
        title,
        author,
        email,
        department,
        field,
        summary: summary || 'Chưa có tóm tắt chi tiết.',
        fileName: uploadedFileName,
        submittedAt: new Date().toISOString().split('T')[0],
        status: 'Đã nộp',
        scores: { novelty: 0, feasibility: 0, impact: 0, total: 0 },
        feedback: 'Chờ thư ký hội đồng tiếp nhận và phân công.'
      };

      saveInitiative(newProposal);
      renderInitiativesTable();
      updateDashboardStats();

      showToast(`✅ Đã nộp thành công sáng kiến ${id}!`, 'success');

      // Reset form
      form.reset();
      currentStep = 1;
      updateStepUI(1);
      if (fileNameDisplay) fileNameDisplay.classList.add('hidden');
    });
  }
}

function validateCurrentStep(step) {
  if (step === 1) {
    const author = document.getElementById('input-author').value.trim();
    const email = document.getElementById('input-email').value.trim();
    const department = document.getElementById('input-department').value;

    if (!author) {
      showToast('Vui lòng nhập họ tên tác giả chính.', 'error');
      document.getElementById('input-author').focus();
      return false;
    }
    if (!email || !email.includes('@')) {
      showToast('Vui lòng nhập email UMP hợp lệ (@ump.edu.vn).', 'error');
      document.getElementById('input-email').focus();
      return false;
    }
    if (!department) {
      showToast('Vui lòng chọn Khoa / Phòng ban công tác.', 'error');
      document.getElementById('input-department').focus();
      return false;
    }
    return true;
  }

  if (step === 2) {
    const title = document.getElementById('input-title').value.trim();
    if (!title) {
      showToast('Vui lòng nhập tên đề tài sáng kiến kinh nghiệm.', 'error');
      document.getElementById('input-title').focus();
      return false;
    }
    return true;
  }

  return true;
}

function updateStepUI(step) {
  for (let i = 1; i <= 3; i++) {
    const content = document.getElementById(`step-content-${i}`);
    const node = document.getElementById(`step-node-${i}`);
    
    if (content) {
      content.classList.toggle('hidden', i !== step);
    }
    
    if (node) {
      const circle = node.querySelector('div');
      if (i <= step) {
        circle.className = 'w-8 h-8 rounded-full bg-[#083B76] text-white text-xs font-bold flex items-center justify-center shadow-md';
      } else {
        circle.className = 'w-8 h-8 rounded-full bg-slate-200 text-slate-600 text-xs font-bold flex items-center justify-center';
      }
    }
  }

  const btnPrev = document.getElementById('btn-prev-step');
  const btnNext = document.getElementById('btn-next-step');
  const btnSubmit = document.getElementById('btn-submit');

  if (btnPrev) btnPrev.classList.toggle('hidden', step === 1);
  if (btnNext) btnNext.classList.toggle('hidden', step === 3);
  if (btnSubmit) btnSubmit.classList.toggle('hidden', step !== 3);
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const bg = type === 'success' ? 'bg-emerald-600' : 'bg-red-600';
  toast.className = `${bg} text-white px-4 py-3 rounded-2xl shadow-xl text-xs font-bold flex items-center space-x-2 toast-enter min-w-[280px]`;
  toast.innerHTML = `<span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
